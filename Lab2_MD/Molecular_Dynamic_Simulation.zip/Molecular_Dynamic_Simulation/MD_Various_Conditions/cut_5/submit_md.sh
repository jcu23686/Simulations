#!/bin/bash
#SBATCH --job-name=GFPMD         
#SBATCH --partition=batch              
#SBATCH --nodes=1                      
#SBATCH --ntasks=10                    
#SBATCH --cpus-per-task=1               
#SBATCH --mem-per-cpu=2gb               
#SBATCH --time=36:00:00                 
#SBATCH --output=GFPMD.%j.out    
#SBATCH --error=GFPMD.%j.err     
#SBATCH --mail-user=jcu23686@uga.edu        
#SBATCH --mail-type=ALL                 

ml Amber/18-fosscuda-2018b-AmberTools-18-patchlevel-10-8
source ${AMBERHOME}/amber.sh
cd $SLURM_SUBMIT_DIR

#Heating
mpiexec --mca mpi_cuda_support 0 ${AMBERHOME}/bin/pmemd.MPI -O \
-i heating.in \
-o heating.out \
-p ../../Lab1_GFP_energy_minimization/gfp.parm7 \
-c ../../Lab1_GFP_energy_minimization/gfp_min_all.rst7 \
-ref ../../Lab1_GFP_energy_minimization/gfp_min_all.rst7 \
-r gfp_heating.rst7 \
-x gfp_heating.nc

#Equilibration
mpiexec --mca mpi_cuda_support 0 ${AMBERHOME}/bin/pmemd.MPI -O \
-i equi.in \
-o equi.out \
-p ../../Lab1_GFP_energy_minimization/gfp.parm7 \
-c gfp_heating.rst7 \
-ref gfp_heating.rst7 \
-r gfp_equi.rst7 \
-x gfp_equi.nc

#Production
mpiexec --mca mpi_cuda_support 0 ${AMBERHOME}/bin/pmemd.MPI -O \
-i md.in \
-o md.out \
-p ../../Lab1_GFP_energy_minimization/gfp.parm7 \
-c gfp_equi.rst7 \
-ref gfp_equi.rst7 \
-r gfp_md.rst7 \
-x gfp_md.nc \
-inf md.info

